import java.util.ArrayList;

public class Graph {
    public ArrayList<Vertex> vlist;

    public Graph() {
    }

    public void addVertex(String name) {
    }

    public Vertex getVertex(String name) {
	return null;
    }
    public void addEdge(String from, String to, int weight) {
    }

    public Edge getEdge(String from, String to) {
	return null;
    }
    
    public int MSTCost() {
	return -1;
    }

    public Graph MST() {
	return null;
    }

    public int SPCost(String from, String to) {
	return 0;
    }

    public Graph SP(String from, String to) {
	return null;
    }
}
